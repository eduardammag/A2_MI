drop schema oper_eal cascade;
drop schema dw_eal cascade;
drop schema audit cascade;